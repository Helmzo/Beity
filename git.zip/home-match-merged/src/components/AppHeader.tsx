import { Link, useRouter } from "@tanstack/react-router";
import { Logo } from "./Logo";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";
import { LogOut, LayoutDashboard, MessageSquare } from "lucide-react";

export function AppHeader({ variant = "public" }: { variant?: "public" | "app" }) {
  const { user, role, signOut } = useAuth();
  const router = useRouter();

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-md">
      <div className="container mx-auto flex h-16 max-w-7xl items-center justify-between px-4">
        <Logo />
        {variant === "public" && (
          <nav className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
            <a href="/#how" className="hover:text-foreground">How it works</a>
            <a href="/#tenants" className="hover:text-foreground">For tenants</a>
            <a href="/#landlords" className="hover:text-foreground">For landlords</a>
            <a href="/#trust" className="hover:text-foreground">Trust</a>
          </nav>
        )}
        <div className="flex items-center gap-2">
          {user ? (
            <>
              <Button variant="ghost" size="sm" onClick={() => router.navigate({ to: "/dashboard" })}>
                <LayoutDashboard className="mr-2 h-4 w-4" />Swipe Zone
              </Button>
              {role !== "admin" && (
                <Button variant="ghost" size="sm" onClick={() => router.navigate({ to: "/messages" })}>
                  <MessageSquare className="mr-2 h-4 w-4" />Messages
                </Button>
              )}
              <Button variant="outline" size="sm" onClick={async () => { await signOut(); router.navigate({ to: "/" }); }}>
                <LogOut className="h-4 w-4" />
              </Button>
              <span className="hidden text-xs text-muted-foreground md:inline">{role}</span>
            </>
          ) : (
            <>
              <Link to="/auth"><Button variant="ghost" size="sm">Sign in</Button></Link>
              <Link to="/auth" search={{ mode: "signup" } as never}><Button size="sm">Get started</Button></Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
