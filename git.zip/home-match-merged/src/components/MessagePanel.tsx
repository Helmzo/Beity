import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import type { DemoMessage } from "@/lib/localStore";
import { MessageSquare, Send } from "lucide-react";

type MessagePanelProps = {
  title: string;
  subtitle: string;
  messages: DemoMessage[];
  currentRole: "tenant" | "landlord";
  onSend: (body: string) => void;
};

export function MessagePanel({ title, subtitle, messages, currentRole, onSend }: MessagePanelProps) {
  const [draft, setDraft] = useState("");

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!draft.trim()) return;
    onSend(draft);
    setDraft("");
  }

  return (
    <Card className="border-border/60 p-4 shadow-card">
      <div className="flex items-start gap-3">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
          <MessageSquare className="h-5 w-5" />
        </span>
        <div className="min-w-0">
          <h3 className="font-semibold text-foreground">{title}</h3>
          <p className="text-xs text-muted-foreground">{subtitle}</p>
        </div>
      </div>

      <div className="mt-4 max-h-64 space-y-2 overflow-y-auto rounded-xl border border-border bg-surface/40 p-3">
        {messages.length ? (
          messages.map((m) => {
            const mine = m.senderRole === currentRole;
            return (
              <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[85%] rounded-2xl px-3 py-2 text-sm ${mine ? "bg-primary text-primary-foreground" : "bg-card text-foreground border border-border"}`}>
                  <div>{m.body}</div>
                  <div className={`mt-1 text-[10px] ${mine ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
                    {new Date(m.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <p className="py-8 text-center text-sm text-muted-foreground">No messages yet. Start the conversation.</p>
        )}
      </div>

      <form onSubmit={submit} className="mt-3 space-y-2">
        <Textarea
          rows={3}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="Write a message..."
        />
        <Button type="submit" className="w-full">
          <Send className="mr-2 h-4 w-4" /> Send message
        </Button>
      </form>
    </Card>
  );
}
