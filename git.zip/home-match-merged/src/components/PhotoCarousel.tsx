import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, ImagePlus } from "lucide-react";

export function PhotoCarousel({
  photos,
  alt,
  className = "h-72",
}: {
  photos: string[];
  alt: string;
  className?: string;
}) {
  const safePhotos = photos?.filter(Boolean) ?? [];
  const [index, setIndex] = useState(0);

  if (!safePhotos.length) {
    return (
      <div className={`flex items-center justify-center rounded-2xl bg-surface text-muted-foreground ${className}`}>
        <div className="text-center text-sm">
          <ImagePlus className="mx-auto mb-2 h-8 w-8" />
          Add photos later
        </div>
      </div>
    );
  }

  const current = safePhotos[index % safePhotos.length];

  return (
    <div className={`group relative overflow-hidden rounded-2xl bg-surface ${className}`}>
      <img src={current} alt={alt} className="h-full w-full object-cover" />
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/60 to-transparent p-3">
        <div className="flex items-center justify-center gap-1.5">
          {safePhotos.map((_, i) => (
            <button
              key={i}
              aria-label={`Show photo ${i + 1}`}
              onClick={() => setIndex(i)}
              className={`h-1.5 rounded-full transition-all ${i === index ? "w-7 bg-white" : "w-1.5 bg-white/60"}`}
            />
          ))}
        </div>
      </div>
      {safePhotos.length > 1 && (
        <>
          <Button
            type="button"
            variant="secondary"
            size="icon"
            className="absolute left-3 top-1/2 h-9 w-9 -translate-y-1/2 rounded-full bg-white/85 opacity-0 shadow-card transition group-hover:opacity-100"
            onClick={() => setIndex((i) => (i - 1 + safePhotos.length) % safePhotos.length)}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            type="button"
            variant="secondary"
            size="icon"
            className="absolute right-3 top-1/2 h-9 w-9 -translate-y-1/2 rounded-full bg-white/85 opacity-0 shadow-card transition group-hover:opacity-100"
            onClick={() => setIndex((i) => (i + 1) % safePhotos.length)}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </>
      )}
    </div>
  );
}
