import { useState, useRef, type PointerEvent, type ReactNode } from "react";

type Props = {
  onSwipe: (dir: "like" | "pass") => void;
  children: ReactNode;
};

export function SwipeCard({ onSwipe, children }: Props) {
  const [drag, setDrag] = useState({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);
  const start = useRef({ x: 0, y: 0 });

  const onDown = (e: PointerEvent<HTMLDivElement>) => {
    setDragging(true);
    start.current = { x: e.clientX, y: e.clientY };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };
  const onMove = (e: PointerEvent<HTMLDivElement>) => {
    if (!dragging) return;
    setDrag({ x: e.clientX - start.current.x, y: e.clientY - start.current.y });
  };
  const onUp = () => {
    if (!dragging) return;
    setDragging(false);
    if (drag.x > 120) {
      animateOff("like");
    } else if (drag.x < -120) {
      animateOff("pass");
    } else {
      setDrag({ x: 0, y: 0 });
    }
  };

  const animateOff = (dir: "like" | "pass") => {
    setDrag({ x: dir === "like" ? 800 : -800, y: drag.y });
    setTimeout(() => {
      onSwipe(dir);
      setDrag({ x: 0, y: 0 });
    }, 220);
  };

  const rot = drag.x / 18;
  const likeOpacity = Math.max(0, Math.min(1, drag.x / 120));
  const passOpacity = Math.max(0, Math.min(1, -drag.x / 120));

  return (
    <div className="relative w-full max-w-sm select-none">
      <div
        className="relative touch-none cursor-grab active:cursor-grabbing"
        style={{
          transform: `translate(${drag.x}px, ${drag.y}px) rotate(${rot}deg)`,
          transition: dragging ? "none" : "transform 220ms ease-out",
        }}
        onPointerDown={onDown}
        onPointerMove={onMove}
        onPointerUp={onUp}
        onPointerCancel={onUp}
      >
        {children}
        <div
          className="pointer-events-none absolute left-4 top-4 rounded-md border-4 border-emerald-400 bg-emerald-400/10 px-3 py-1 text-xl font-black uppercase tracking-widest text-emerald-400"
          style={{ opacity: likeOpacity, transform: "rotate(-12deg)" }}
        >
          Match
        </div>
        <div
          className="pointer-events-none absolute right-4 top-4 rounded-md border-4 border-rose-400 bg-rose-400/10 px-3 py-1 text-xl font-black uppercase tracking-widest text-rose-400"
          style={{ opacity: passOpacity, transform: "rotate(12deg)" }}
        >
          Nope
        </div>
      </div>
      <div className="mt-6 flex items-center justify-center gap-6">
        <button
          onClick={() => animateOff("pass")}
          className="flex h-14 w-14 items-center justify-center rounded-full border border-rose-200 bg-white text-2xl text-rose-500 shadow-md transition hover:scale-110 hover:bg-rose-50"
          aria-label="Pass"
        >
          ✕
        </button>
        <button
          onClick={() => animateOff("like")}
          className="flex h-14 w-14 items-center justify-center rounded-full border border-emerald-200 bg-white text-2xl text-emerald-500 shadow-md transition hover:scale-110 hover:bg-emerald-50"
          aria-label="Like"
        >
          ♥
        </button>
      </div>
    </div>
  );
}
