export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      bookings: {
        Row: {
          created_at: string
          id: string
          landlord_id: string
          match_id: string
          slot_id: string
          status: Database["public"]["Enums"]["booking_status"]
          tenant_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          landlord_id: string
          match_id: string
          slot_id: string
          status?: Database["public"]["Enums"]["booking_status"]
          tenant_id: string
        }
        Update: {
          created_at?: string
          id?: string
          landlord_id?: string
          match_id?: string
          slot_id?: string
          status?: Database["public"]["Enums"]["booking_status"]
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bookings_match_id_fkey"
            columns: ["match_id"]
            isOneToOne: false
            referencedRelation: "matches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookings_slot_id_fkey"
            columns: ["slot_id"]
            isOneToOne: true
            referencedRelation: "visit_slots"
            referencedColumns: ["id"]
          },
        ]
      }
      document_unlocks: {
        Row: {
          created_at: string
          document_id: string
          id: string
          match_id: string
        }
        Insert: {
          created_at?: string
          document_id: string
          id?: string
          match_id: string
        }
        Update: {
          created_at?: string
          document_id?: string
          id?: string
          match_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "document_unlocks_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "tenant_documents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "document_unlocks_match_id_fkey"
            columns: ["match_id"]
            isOneToOne: false
            referencedRelation: "matches"
            referencedColumns: ["id"]
          },
        ]
      }
      landlord_profiles: {
        Row: {
          company_name: string | null
          created_at: string
          id: string
          is_agency: boolean
          updated_at: string
        }
        Insert: {
          company_name?: string | null
          created_at?: string
          id: string
          is_agency?: boolean
          updated_at?: string
        }
        Update: {
          company_name?: string | null
          created_at?: string
          id?: string
          is_agency?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      match_interests: {
        Row: {
          created_at: string
          id: string
          landlord_id: string
          property_id: string
          responded_at: string | null
          score: number
          status: Database["public"]["Enums"]["interest_status"]
          tenant_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          landlord_id: string
          property_id: string
          responded_at?: string | null
          score?: number
          status?: Database["public"]["Enums"]["interest_status"]
          tenant_id: string
        }
        Update: {
          created_at?: string
          id?: string
          landlord_id?: string
          property_id?: string
          responded_at?: string | null
          score?: number
          status?: Database["public"]["Enums"]["interest_status"]
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "match_interests_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
        ]
      }
      matches: {
        Row: {
          created_at: string
          id: string
          interest_id: string
          landlord_id: string
          property_id: string
          status: Database["public"]["Enums"]["match_status"]
          tenant_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          interest_id: string
          landlord_id: string
          property_id: string
          status?: Database["public"]["Enums"]["match_status"]
          tenant_id: string
        }
        Update: {
          created_at?: string
          id?: string
          interest_id?: string
          landlord_id?: string
          property_id?: string
          status?: Database["public"]["Enums"]["match_status"]
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "matches_interest_id_fkey"
            columns: ["interest_id"]
            isOneToOne: true
            referencedRelation: "match_interests"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "matches_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          body: string
          created_at: string
          id: string
          match_id: string
          sender_id: string
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          match_id: string
          sender_id: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          match_id?: string
          sender_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_match_id_fkey"
            columns: ["match_id"]
            isOneToOne: false
            referencedRelation: "matches"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          body: string | null
          created_at: string
          id: string
          link: string | null
          read: boolean
          title: string
          user_id: string
        }
        Insert: {
          body?: string | null
          created_at?: string
          id?: string
          link?: string | null
          read?: boolean
          title: string
          user_id: string
        }
        Update: {
          body?: string | null
          created_at?: string
          id?: string
          link?: string | null
          read?: boolean
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          city: string | null
          created_at: string
          full_name: string | null
          id: string
          phone: string | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          city?: string | null
          created_at?: string
          full_name?: string | null
          id: string
          phone?: string | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          city?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          phone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      properties: {
        Row: {
          active: boolean
          address: string | null
          area: string | null
          available_date: string
          city: string
          created_at: string
          description: string | null
          furnished: boolean
          housing_type: Database["public"]["Enums"]["housing_type"]
          id: string
          landlord_id: string
          photos: string[] | null
          rent: number
          required_docs: string[] | null
          rooms: number
          rules: string | null
          surface: number | null
          term: Database["public"]["Enums"]["property_term"]
          title: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          address?: string | null
          area?: string | null
          available_date: string
          city: string
          created_at?: string
          description?: string | null
          furnished?: boolean
          housing_type?: Database["public"]["Enums"]["housing_type"]
          id?: string
          landlord_id: string
          photos?: string[] | null
          rent: number
          required_docs?: string[] | null
          rooms?: number
          rules?: string | null
          surface?: number | null
          term?: Database["public"]["Enums"]["property_term"]
          title: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          address?: string | null
          area?: string | null
          available_date?: string
          city?: string
          created_at?: string
          description?: string | null
          furnished?: boolean
          housing_type?: Database["public"]["Enums"]["housing_type"]
          id?: string
          landlord_id?: string
          photos?: string[] | null
          rent?: number
          required_docs?: string[] | null
          rooms?: number
          rules?: string | null
          surface?: number | null
          term?: Database["public"]["Enums"]["property_term"]
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      reports: {
        Row: {
          created_at: string
          id: string
          reason: string
          reporter_id: string
          resolved: boolean
          target_property_id: string | null
          target_user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          reason: string
          reporter_id: string
          resolved?: boolean
          target_property_id?: string | null
          target_user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          reason?: string
          reporter_id?: string
          resolved?: boolean
          target_property_id?: string | null
          target_user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "reports_target_property_id_fkey"
            columns: ["target_property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
        ]
      }
      tenant_documents: {
        Row: {
          created_at: string
          doc_type: Database["public"]["Enums"]["doc_type"]
          filename: string
          id: string
          storage_path: string
          tenant_id: string
          verification: Database["public"]["Enums"]["verification_status"]
        }
        Insert: {
          created_at?: string
          doc_type: Database["public"]["Enums"]["doc_type"]
          filename: string
          id?: string
          storage_path: string
          tenant_id: string
          verification?: Database["public"]["Enums"]["verification_status"]
        }
        Update: {
          created_at?: string
          doc_type?: Database["public"]["Enums"]["doc_type"]
          filename?: string
          id?: string
          storage_path?: string
          tenant_id?: string
          verification?: Database["public"]["Enums"]["verification_status"]
        }
        Relationships: []
      }
      tenant_profiles: {
        Row: {
          age: number | null
          budget_max: number | null
          budget_min: number | null
          completion: number
          created_at: string
          desired_area: string | null
          desired_city: string | null
          furnished: boolean | null
          has_guarantor: boolean | null
          has_pets: boolean | null
          housing_type: Database["public"]["Enums"]["housing_type"] | null
          id: string
          income_max: number | null
          income_min: number | null
          intro: string | null
          is_verified: boolean
          move_in_date: string | null
          situation: Database["public"]["Enums"]["tenant_situation"] | null
          smoker: boolean | null
          stay_months: number | null
          updated_at: string
        }
        Insert: {
          age?: number | null
          budget_max?: number | null
          budget_min?: number | null
          completion?: number
          created_at?: string
          desired_area?: string | null
          desired_city?: string | null
          furnished?: boolean | null
          has_guarantor?: boolean | null
          has_pets?: boolean | null
          housing_type?: Database["public"]["Enums"]["housing_type"] | null
          id: string
          income_max?: number | null
          income_min?: number | null
          intro?: string | null
          is_verified?: boolean
          move_in_date?: string | null
          situation?: Database["public"]["Enums"]["tenant_situation"] | null
          smoker?: boolean | null
          stay_months?: number | null
          updated_at?: string
        }
        Update: {
          age?: number | null
          budget_max?: number | null
          budget_min?: number | null
          completion?: number
          created_at?: string
          desired_area?: string | null
          desired_city?: string | null
          furnished?: boolean | null
          has_guarantor?: boolean | null
          has_pets?: boolean | null
          housing_type?: Database["public"]["Enums"]["housing_type"] | null
          id?: string
          income_max?: number | null
          income_min?: number | null
          intro?: string | null
          is_verified?: boolean
          move_in_date?: string | null
          situation?: Database["public"]["Enums"]["tenant_situation"] | null
          smoker?: boolean | null
          stay_months?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      verification_badges: {
        Row: {
          badge: string
          created_at: string
          granted_by: string | null
          id: string
          tenant_id: string
        }
        Insert: {
          badge: string
          created_at?: string
          granted_by?: string | null
          id?: string
          tenant_id: string
        }
        Update: {
          badge?: string
          created_at?: string
          granted_by?: string | null
          id?: string
          tenant_id?: string
        }
        Relationships: []
      }
      visit_slots: {
        Row: {
          created_at: string
          duration_min: number
          id: string
          is_booked: boolean
          landlord_id: string
          property_id: string
          starts_at: string
        }
        Insert: {
          created_at?: string
          duration_min?: number
          id?: string
          is_booked?: boolean
          landlord_id: string
          property_id: string
          starts_at: string
        }
        Update: {
          created_at?: string
          duration_min?: number
          id?: string
          is_booked?: boolean
          landlord_id?: string
          property_id?: string
          starts_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "visit_slots_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin: { Args: { _user_id: string }; Returns: boolean }
    }
    Enums: {
      app_role: "tenant" | "landlord" | "admin"
      booking_status: "booked" | "cancelled" | "completed"
      doc_type:
        | "id"
        | "income"
        | "student_certificate"
        | "employment_contract"
        | "guarantor"
        | "other"
      housing_type: "studio" | "apartment" | "house" | "room" | "colocation"
      interest_status: "pending" | "accepted" | "declined"
      match_status: "active" | "closed"
      property_term: "short" | "medium" | "long"
      tenant_situation:
        | "student"
        | "employee"
        | "intern"
        | "expat"
        | "young_professional"
        | "other"
      verification_status: "pending" | "approved" | "rejected"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["tenant", "landlord", "admin"],
      booking_status: ["booked", "cancelled", "completed"],
      doc_type: [
        "id",
        "income",
        "student_certificate",
        "employment_contract",
        "guarantor",
        "other",
      ],
      housing_type: ["studio", "apartment", "house", "room", "colocation"],
      interest_status: ["pending", "accepted", "declined"],
      match_status: ["active", "closed"],
      property_term: ["short", "medium", "long"],
      tenant_situation: [
        "student",
        "employee",
        "intern",
        "expat",
        "young_professional",
        "other",
      ],
      verification_status: ["pending", "approved", "rejected"],
    },
  },
} as const
