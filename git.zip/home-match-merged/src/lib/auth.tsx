import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Session, User } from "@supabase/supabase-js";

export type Role = "tenant" | "landlord" | "admin";

interface AuthCtx {
  user: User | null;
  session: Session | null;
  role: Role | null;
  loading: boolean;
  refresh: () => Promise<void>;
  signOut: () => Promise<void>;
}

const Ctx = createContext<AuthCtx | null>(null);

const DEMO_USER_ID = "00000000-0000-4000-8000-000000000001";
const DEMO_EMAIL = "demo@homematch.local";
const DEMO_AUTH_KEY = "homematch-demo-auth";
const DEMO_ROLE_KEY = "homematch-demo-role";

function makeDemoUser(): User {
  return {
    id: DEMO_USER_ID,
    email: DEMO_EMAIL,
    app_metadata: {},
    user_metadata: { full_name: "Demo User" },
    aud: "authenticated",
    created_at: new Date().toISOString(),
  } as User;
}

function getStoredRole(): Role {
  const stored = localStorage.getItem(DEMO_ROLE_KEY);
  if (stored === "tenant" || stored === "landlord" || stored === "admin") return stored;
  return "tenant";
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session] = useState<Session | null>(null);
  const [role, setRole] = useState<Role | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = async () => {
    const isAuthed = localStorage.getItem(DEMO_AUTH_KEY) === "true";

    if (isAuthed) {
      setUser(makeDemoUser());
      setRole(getStoredRole());
    } else {
      setUser(null);
      setRole(null);
    }
  };

  useEffect(() => {
    refresh().finally(() => setLoading(false));

    function syncDemoAuth() {
      refresh();
    }

    window.addEventListener("storage", syncDemoAuth);
    window.addEventListener("homematch-demo-auth-changed", syncDemoAuth);

    return () => {
      window.removeEventListener("storage", syncDemoAuth);
      window.removeEventListener("homematch-demo-auth-changed", syncDemoAuth);
    };
  }, []);

  const signOut = async () => {
    localStorage.removeItem(DEMO_AUTH_KEY);
    localStorage.removeItem(DEMO_ROLE_KEY);
    setUser(null);
    setRole(null);
    window.dispatchEvent(new Event("homematch-demo-auth-changed"));
  };

  return (
    <Ctx.Provider value={{ user, session, role, loading, refresh, signOut }}>
      {children}
    </Ctx.Provider>
  );
}

export function useAuth() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useAuth must be used inside AuthProvider");
  return v;
}
