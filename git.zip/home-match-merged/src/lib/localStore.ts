import { useCallback, useEffect, useState } from "react";

export type Role = "tenant" | "landlord" | "admin";
export type SwipeDirection = "like" | "pass";

export type TenantProfile = {
  id: string;
  name: string;
  age: number;
  occupation: string;
  monthlyIncome: number;
  budget: number;
  householdSize: number;
  pets: boolean;
  smoker: boolean;
  bio: string;
  photo: string;
  photos: string[];
  moveInDate: string;
  preferredDistrict: string;
  desiredCity: string;
  hasGuarantor: boolean;
};

export type Property = {
  id: string;
  title: string;
  district: string;
  city: string;
  rent: number;
  bedrooms: number;
  bathrooms: number;
  sizeSqm: number;
  furnished: boolean;
  petsAllowed: boolean;
  description: string;
  photos: string[];
  landlordName: string;
  availableDate: string;
};

export type DemoMessage = {
  id: string;
  conversationId: string;
  senderRole: "tenant" | "landlord";
  body: string;
  createdAt: string;
};

export type SwipeMap = Record<string, SwipeDirection>;
export type MessageMap = Record<string, DemoMessage[]>;

export type AppState = {
  myTenant: TenantProfile | null;
  myProperty: Property | null;
  tenants: TenantProfile[];
  properties: Property[];
  tenantSwipesOnProps: SwipeMap;
  landlordSwipesOnTenants: SwipeMap;
  messages: MessageMap;
};

const KEY = "homematch-demo-state-v4";

const tenantPhotos = [
  "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=900&q=80",
  "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=900&q=80",
  "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=900&q=80",
];

export const SEED_TENANTS: TenantProfile[] = [
  {
    id: "t1",
    name: "Amelia Rivera",
    age: 28,
    occupation: "UX Designer",
    monthlyIncome: 5200,
    budget: 1600,
    householdSize: 1,
    pets: false,
    smoker: false,
    bio: "Tidy, quiet, work-from-home most days. Loves plants and calm Sunday mornings.",
    photo: tenantPhotos[0],
    photos: tenantPhotos,
    moveInDate: "2026-07-01",
    preferredDistrict: "Mitte",
    desiredCity: "Berlin",
    hasGuarantor: true,
  },
  {
    id: "t2",
    name: "Jonas Becker",
    age: 32,
    occupation: "Software Engineer",
    monthlyIncome: 6800,
    budget: 2000,
    householdSize: 2,
    pets: true,
    smoker: false,
    bio: "Engineer + partner + one small polite dog. Looking for a long-term home.",
    photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=900&q=80",
    photos: [
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=900&q=80",
      "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=900&q=80",
      "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=900&q=80",
    ],
    moveInDate: "2026-08-15",
    preferredDistrict: "Prenzlauer Berg",
    desiredCity: "Berlin",
    hasGuarantor: true,
  },
  {
    id: "t3",
    name: "Sofia Martins",
    age: 26,
    occupation: "Nurse",
    monthlyIncome: 3900,
    budget: 1300,
    householdSize: 1,
    pets: false,
    smoker: false,
    bio: "Night shifts at the hospital. Quiet, respectful, great references.",
    photo: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=900&q=80",
    photos: [
      "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=900&q=80",
      "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=900&q=80",
    ],
    moveInDate: "2026-06-15",
    preferredDistrict: "Kreuzberg",
    desiredCity: "Berlin",
    hasGuarantor: false,
  },
];

export const SEED_PROPERTIES: Property[] = [
  {
    id: "p1",
    title: "Sunlit loft with balcony",
    district: "Prenzlauer Berg",
    city: "Berlin",
    rent: 1850,
    bedrooms: 2,
    bathrooms: 1,
    sizeSqm: 78,
    furnished: true,
    petsAllowed: true,
    description: "Top-floor loft with oak floors, big windows and a south-facing balcony. Walk to cafés and the U-Bahn.",
    photos: [
      "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=1200&q=80",
      "https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=1200&q=80",
      "https://images.unsplash.com/photo-1484154218962-a197022b5858?w=1200&q=80",
    ],
    landlordName: "Klaus M.",
    availableDate: "2026-07-01",
  },
  {
    id: "p2",
    title: "Cozy 1-bed near the canal",
    district: "Kreuzberg",
    city: "Berlin",
    rent: 1250,
    bedrooms: 1,
    bathrooms: 1,
    sizeSqm: 46,
    furnished: false,
    petsAllowed: false,
    description: "Quiet courtyard apartment, fresh paint, kitchen renovated last year. Steps from Landwehrkanal.",
    photos: [
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?w=1200&q=80",
      "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=1200&q=80",
      "https://images.unsplash.com/photo-1540518614846-7eded433c457?w=1200&q=80",
    ],
    landlordName: "Renata S.",
    availableDate: "2026-08-01",
  },
  {
    id: "p3",
    title: "Family flat with garden access",
    district: "Charlottenburg",
    city: "Berlin",
    rent: 2400,
    bedrooms: 3,
    bathrooms: 2,
    sizeSqm: 112,
    furnished: false,
    petsAllowed: true,
    description: "Spacious pre-war flat with stucco ceilings, two balconies and shared garden. Great schools nearby.",
    photos: [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=1200&q=80",
      "https://images.unsplash.com/photo-1567016432779-094069958ea5?w=1200&q=80",
    ],
    landlordName: "Thomas W.",
    availableDate: "2026-09-01",
  },
];

function freshState(): AppState {
  return {
    myTenant: null,
    myProperty: null,
    tenants: SEED_TENANTS,
    properties: SEED_PROPERTIES,
    tenantSwipesOnProps: {},
    landlordSwipesOnTenants: {},
    messages: {},
  };
}

function normalize(raw: Partial<AppState>): AppState {
  return {
    ...freshState(),
    ...raw,
    tenants: raw.tenants?.length ? raw.tenants : SEED_TENANTS,
    properties: raw.properties?.length ? raw.properties : SEED_PROPERTIES,
    tenantSwipesOnProps: raw.tenantSwipesOnProps ?? {},
    landlordSwipesOnTenants: raw.landlordSwipesOnTenants ?? {},
    messages: raw.messages ?? {},
  };
}

function load(): AppState {
  if (typeof window === "undefined") return freshState();
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return normalize(JSON.parse(raw));
  } catch {}
  return freshState();
}

const listeners = new Set<() => void>();
let state: AppState = load();

function save() {
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch {}
  listeners.forEach((l) => l());
}

export function conversationId(tenantId: string, propertyId: string) {
  return `${tenantId}__${propertyId}`;
}

export function isTenantPropertyMatch(s: AppState, tenantId: string, propertyId: string) {
  const tenantLikedProperty = s.tenantSwipesOnProps[propertyId] === "like";
  const landlordLikedTenant = s.landlordSwipesOnTenants[tenantId] === "like";

  // In this demo there is one active landlord property, so landlord likes apply to that property.
  const landlordOwnsProperty = s.myProperty?.id === propertyId;

  return tenantLikedProperty && landlordLikedTenant && landlordOwnsProperty;
}

export function getTenantLikedProperties(s: AppState) {
  return s.properties.filter((p) => s.tenantSwipesOnProps[p.id] === "like");
}

export function getLandlordLikedTenants(s: AppState) {
  return s.tenants.filter((t) => s.landlordSwipesOnTenants[t.id] === "like");
}

export function getTenantMatches(s: AppState) {
  if (!s.myTenant) return [];
  return s.properties.filter((p) => isTenantPropertyMatch(s, s.myTenant!.id, p.id));
}

export function getLandlordMatches(s: AppState) {
  if (!s.myProperty) return [];
  return s.tenants.filter((t) => isTenantPropertyMatch(s, t.id, s.myProperty!.id));
}

export function useLocalStore() {
  const [, setTick] = useState(0);

  useEffect(() => {
    const l = () => setTick((n) => n + 1);
    listeners.add(l);
    state = load();
    l();
    return () => {
      listeners.delete(l);
    };
  }, []);

  const saveTenant = useCallback((tenant: TenantProfile) => {
    const photos = tenant.photos?.filter(Boolean).length ? tenant.photos.filter(Boolean) : [tenant.photo].filter(Boolean);
    const normalized = { ...tenant, photo: photos[0] || tenant.photo, photos };
    state = {
      ...state,
      myTenant: normalized,
      tenants: [normalized, ...state.tenants.filter((t) => t.id !== normalized.id)],
    };
    save();
  }, []);

  const saveProperty = useCallback((property: Property) => {
    const photos = property.photos?.filter(Boolean).length ? property.photos.filter(Boolean) : [];
    const normalized = { ...property, photos };
    state = {
      ...state,
      myProperty: normalized,
      properties: [normalized, ...state.properties.filter((p) => p.id !== normalized.id)],
    };
    save();
  }, []);

  const swipeProperty = useCallback((propId: string, dir: SwipeDirection) => {
    state = {
      ...state,
      tenantSwipesOnProps: { ...state.tenantSwipesOnProps, [propId]: dir },
    };
    save();
  }, []);

  const swipeTenant = useCallback((tenantId: string, dir: SwipeDirection) => {
    state = {
      ...state,
      landlordSwipesOnTenants: { ...state.landlordSwipesOnTenants, [tenantId]: dir },
    };
    save();
  }, []);

  const sendMessage = useCallback((id: string, senderRole: "tenant" | "landlord", body: string) => {
    const clean = body.trim();
    if (!clean) return;

    const message: DemoMessage = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      conversationId: id,
      senderRole,
      body: clean,
      createdAt: new Date().toISOString(),
    };

    state = {
      ...state,
      messages: {
        ...state.messages,
        [id]: [...(state.messages[id] ?? []), message],
      },
    };
    save();
  }, []);

  const resetDemoData = useCallback(() => {
    localStorage.removeItem(KEY);
    state = freshState();
    save();
  }, []);

  return { state, saveTenant, saveProperty, swipeProperty, swipeTenant, sendMessage, resetDemoData };
}

export function splitPhotoInput(value: string): string[] {
  return value
    .split(/\n|,/)
    .map((p) => p.trim())
    .filter(Boolean);
}
