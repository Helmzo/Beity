// Compatibility scoring between a tenant profile and a property.
// Returns 0-100 score with explanation factors.

export interface TenantInput {
  desired_city?: string | null;
  desired_area?: string | null;
  budget_min?: number | null;
  budget_max?: number | null;
  move_in_date?: string | null;
  stay_months?: number | null;
  housing_type?: string | null;
  furnished?: boolean | null;
  situation?: string | null;
  has_guarantor?: boolean | null;
  has_pets?: boolean | null;
  smoker?: boolean | null;
  completion?: number | null;
  is_verified?: boolean | null;
}

export interface PropertyInput {
  city: string;
  area?: string | null;
  rent: number;
  available_date: string;
  term?: string | null;
  housing_type?: string | null;
  furnished?: boolean | null;
  rules?: string | null;
}

export interface Verification {
  badges?: string[];
}

export interface MatchResult {
  score: number;
  label: "Excellent" | "Good" | "Medium" | "Low";
  factors: { label: string; pass: boolean }[];
}

export function computeMatch(t: TenantInput, p: PropertyInput, v: Verification = {}): MatchResult {
  let score = 0;
  const factors: { label: string; pass: boolean }[] = [];

  // Budget (25)
  const budgetOk = t.budget_max != null && p.rent <= t.budget_max && (t.budget_min == null || p.rent >= t.budget_min - 100);
  if (budgetOk) score += 25;
  factors.push({ label: budgetOk ? "Budget fits the rent" : "Rent is outside your budget", pass: budgetOk });

  // City (20)
  const cityOk = !!(t.desired_city && p.city && t.desired_city.toLowerCase() === p.city.toLowerCase());
  if (cityOk) score += 20;
  factors.push({ label: cityOk ? `Located in ${p.city}` : `Different city (${p.city})`, pass: cityOk });

  // Area (5)
  const areaOk = !!(t.desired_area && p.area && p.area.toLowerCase().includes(t.desired_area.toLowerCase()));
  if (areaOk) score += 5;

  // Move-in date (15) — within 14 days
  let dateOk = false;
  if (t.move_in_date && p.available_date) {
    const td = new Date(t.move_in_date).getTime();
    const pd = new Date(p.available_date).getTime();
    dateOk = Math.abs(td - pd) <= 1000 * 60 * 60 * 24 * 14;
    if (dateOk) score += 15;
    else if (pd <= td) score += 8;
  }
  factors.push({ label: dateOk ? "Move-in dates align" : "Move-in dates differ", pass: dateOk });

  // Stay duration vs term (8)
  if (t.stay_months && p.term) {
    const longEnough =
      (p.term === "short" && t.stay_months <= 4) ||
      (p.term === "medium" && t.stay_months > 3 && t.stay_months <= 9) ||
      (p.term === "long" && t.stay_months >= 6);
    if (longEnough) score += 8;
    factors.push({ label: longEnough ? "Stay duration matches" : "Stay duration mismatch", pass: longEnough });
  }

  // Furnished (5)
  if (t.furnished != null && p.furnished != null) {
    const f = t.furnished === p.furnished;
    if (f) score += 5;
  }

  // Housing type (5)
  if (t.housing_type && p.housing_type && t.housing_type === p.housing_type) score += 5;

  // Guarantor (7) — most landlords value it
  if (t.has_guarantor) {
    score += 7;
    factors.push({ label: "Guarantor available", pass: true });
  } else {
    factors.push({ label: "No guarantor", pass: false });
  }

  // Rules (pets/smoking) (5)
  const rules = (p.rules || "").toLowerCase();
  const petsBlocked = rules.includes("no pets") && t.has_pets;
  const smokingBlocked = (rules.includes("no smoking") || rules.includes("non-smoking")) && t.smoker;
  if (!petsBlocked && !smokingBlocked) score += 5;
  if (petsBlocked) factors.push({ label: "Pets not allowed here", pass: false });
  if (smokingBlocked) factors.push({ label: "Smoking not allowed here", pass: false });

  // Verification (5)
  if (v.badges && v.badges.length >= 2) {
    score += 5;
    factors.push({ label: "Verified profile", pass: true });
  }

  score = Math.max(0, Math.min(100, Math.round(score)));
  const label: MatchResult["label"] = score >= 80 ? "Excellent" : score >= 60 ? "Good" : score >= 40 ? "Medium" : "Low";
  return { score, label, factors: factors.slice(0, 5) };
}

export function computeCompletion(t: TenantInput): number {
  const keys: (keyof TenantInput)[] = [
    "desired_city", "budget_max", "move_in_date", "stay_months",
    "housing_type", "furnished", "situation", "has_guarantor",
  ];
  let filled = 0;
  for (const k of keys) if (t[k] != null && t[k] !== "") filled++;
  return Math.round((filled / keys.length) * 100);
}
