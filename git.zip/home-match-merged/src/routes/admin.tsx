import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/lib/auth";
import { useLocalStore } from "@/lib/localStore";
import { RotateCcw, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/admin")({ component: AdminPage });

function AdminPage() {
  const nav = useNavigate();
  const { user, role, loading } = useAuth();
  const { state, resetDemoData } = useLocalStore();

  useEffect(() => {
    if (loading) return;
    if (!user) nav({ to: "/auth" });
    else if (role !== "admin") nav({ to: "/dashboard" });
  }, [loading, user, role, nav]);

  return (
    <div className="min-h-screen bg-background">
      <AppHeader variant="app" />
      <main className="container mx-auto max-w-5xl px-4 py-10">
        <Badge variant="secondary" className="mb-3"><ShieldCheck className="mr-1 h-3 w-3" />Admin demo</Badge>
        <h1 className="font-display text-5xl text-foreground">Local demo control panel</h1>
        <p className="mt-2 text-muted-foreground">This version uses localStorage. Information survives refresh on the same browser.</p>
        <div className="mt-8 grid gap-4 md:grid-cols-4">
          <Stat title="Tenants" value={state.tenants.length} />
          <Stat title="Properties" value={state.properties.length} />
          <Stat title="Tenant swipes" value={Object.keys(state.tenantSwipesOnProps).length} />
          <Stat title="Landlord swipes" value={Object.keys(state.landlordSwipesOnTenants).length} />
        </div>
        <Card className="mt-8 border-border/60 p-6 shadow-card">
          <h2 className="text-xl font-semibold text-foreground">Reset local demo data</h2>
          <p className="mt-1 text-sm text-muted-foreground">This clears profiles, swipes, and matches from localStorage.</p>
          <Button variant="outline" className="mt-4" onClick={resetDemoData}><RotateCcw className="mr-2 h-4 w-4" />Reset data</Button>
        </Card>
      </main>
    </div>
  );
}

function Stat({ title, value }: { title: string; value: number }) {
  return <Card className="border-border/60 p-5 shadow-card"><div className="text-sm text-muted-foreground">{title}</div><div className="mt-2 font-display text-4xl text-primary">{value}</div></Card>;
}
