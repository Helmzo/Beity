import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useAuth } from "@/lib/auth";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { Home, Building2, ShieldCheck } from "lucide-react";

type AuthSearch = { mode?: "signin" | "signup"; role?: "tenant" | "landlord" | "admin" };
type DemoRole = "tenant" | "landlord" | "admin";

const DEMO_PASSWORD = "demo123";
const DEMO_AUTH_KEY = "homematch-demo-auth";
const DEMO_ROLE_KEY = "homematch-demo-role";

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>): AuthSearch => ({
    mode: s.mode === "signup" ? "signup" : "signin",
    role: (["tenant", "landlord", "admin"] as const).includes(s.role as never)
      ? (s.role as AuthSearch["role"])
      : undefined,
  }),
  component: AuthPage,
});

function AuthPage() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const { user, role: currentRole, refresh } = useAuth();
  const [password, setPassword] = useState(DEMO_PASSWORD);
  const [role, setRole] = useState<DemoRole>(search.role ?? "tenant");
  const [loading, setLoading] = useState(false);

  if (user && currentRole) {
    navigate({ to: "/dashboard" });
  }

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();

    if (password !== DEMO_PASSWORD) {
      toast.error("Wrong demo password. Use demo123.");
      return;
    }

    setLoading(true);
    localStorage.setItem(DEMO_AUTH_KEY, "true");
    localStorage.setItem(DEMO_ROLE_KEY, role);
    window.dispatchEvent(new Event("homematch-demo-auth-changed"));
    await refresh();
    toast.success("Demo unlocked");
    navigate({ to: "/dashboard" });
    setLoading(false);
  }

  function quickEnter(selectedRole: DemoRole) {
    localStorage.setItem(DEMO_AUTH_KEY, "true");
    localStorage.setItem(DEMO_ROLE_KEY, selectedRole);
    window.dispatchEvent(new Event("homematch-demo-auth-changed"));
    refresh().then(() => navigate({ to: "/dashboard" }));
  }

  return (
    <div className="min-h-screen bg-hero">
      <AppHeader variant="public" />
      <div className="container mx-auto flex max-w-md flex-col justify-center px-4 py-16">
        <Card className="border-border/60 p-8 shadow-elegant">
          <h1 className="font-display text-3xl text-foreground">HomeMatch Demo Login</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Supabase authentication is disabled for this portfolio demo. Use the saved demo password below.
          </p>

          <form onSubmit={submit} className="mt-6 space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="password">Demo password</Label>
              <Input
                id="password"
                name="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <p className="text-xs text-muted-foreground">Saved password: demo123</p>
            </div>

            <div className="space-y-1.5">
              <Label>Open as</Label>
              <div className="grid gap-2">
                <RoleCard
                  selected={role === "tenant"}
                  icon={<Home className="h-5 w-5" />}
                  title="Tenant"
                  desc="Find a verified, pre-approved home"
                  onClick={() => setRole("tenant")}
                />
                <RoleCard
                  selected={role === "landlord"}
                  icon={<Building2 className="h-5 w-5" />}
                  title="Landlord"
                  desc="List properties and pre-approve tenants"
                  onClick={() => setRole("landlord")}
                />
                <RoleCard
                  selected={role === "admin"}
                  icon={<ShieldCheck className="h-5 w-5" />}
                  title="Admin"
                  desc="Manage the platform"
                  onClick={() => setRole("admin")}
                />
              </div>
            </div>

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Opening demo…" : "Enter demo"}
            </Button>
          </form>

          <div className="mt-4 grid grid-cols-3 gap-2">
            <Button variant="outline" size="sm" onClick={() => quickEnter("tenant")}>Tenant</Button>
            <Button variant="outline" size="sm" onClick={() => quickEnter("landlord")}>Landlord</Button>
            <Button variant="outline" size="sm" onClick={() => quickEnter("admin")}>Admin</Button>
          </div>

          <div className="mt-4 text-xs">
            <Link to="/" className="text-muted-foreground hover:text-foreground">Back to home</Link>
          </div>
        </Card>
      </div>
    </div>
  );
}

function RoleCard({
  icon,
  title,
  desc,
  selected,
  onClick,
}: {
  icon: React.ReactNode;
  title: string;
  desc: string;
  selected: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`w-full rounded-lg border p-4 text-left transition hover:border-primary/50 hover:shadow-card ${
        selected ? "border-primary bg-primary/10" : "border-border bg-card"
      }`}
    >
      <div className="flex items-center gap-3">
        <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">{icon}</span>
        <div>
          <div className="font-semibold text-foreground">{title}</div>
          <div className="text-xs text-muted-foreground">{desc}</div>
        </div>
      </div>
    </button>
  );
}
