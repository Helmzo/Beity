import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/dashboard")({ component: DashboardRouter });

function DashboardRouter() {
  const { user, role, loading } = useAuth();
  const nav = useNavigate();
  useEffect(() => {
    if (loading) return;
    if (!user) { nav({ to: "/auth" }); return; }
    if (!role) { nav({ to: "/auth" }); return; }
    if (role === "tenant") nav({ to: "/tenant" });
    else if (role === "landlord") nav({ to: "/landlord" });
    else if (role === "admin") nav({ to: "/admin" });
  }, [user, role, loading, nav]);
  return (
    <div className="flex min-h-screen items-center justify-center text-muted-foreground">Loading your Swipe Zone…</div>
  );
}
