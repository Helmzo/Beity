import { createFileRoute, Link } from "@tanstack/react-router";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  ShieldCheck, Sparkles, CalendarCheck, Lock, ArrowRight,
  Building2, Users, FileCheck2, MessageSquare, Star,
} from "lucide-react";

export const Route = createFileRoute("/")({
  component: Landing,
  head: () => ({
    meta: [
      { title: "HomeMatch — Verified renters, pre-approved by landlords" },
      { name: "description", content: "Stop applying to 50 apartments. Create one verified renter profile, get matched with landlords who already showed interest, and book visits directly in the app." },
    ],
  }),
});

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <AppHeader variant="public" />

      {/* HERO */}
      <section className="relative overflow-hidden bg-hero">
        <div className="container mx-auto max-w-7xl px-4 py-20 md:py-28">
          <div className="mx-auto max-w-3xl text-center">
            <Badge variant="secondary" className="mb-6 gap-1.5 rounded-full px-3 py-1 text-xs">
              <Sparkles className="h-3 w-3" /> Trusted by 1,200+ renters across France
            </Badge>
            <h1 className="font-display text-5xl leading-[1.05] text-balance text-foreground md:text-7xl">
              Stop applying to 50 apartments. Let compatible landlords come to you.
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg text-muted-foreground">
              Create one verified renter profile, get matched with landlords who already showed interest, and book visits directly in the app.
            </p>
            <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Link to="/auth" search={{ mode: "signup", role: "tenant" } as never}>
                <Button size="lg" className="h-12 w-full px-7 text-base shadow-elegant sm:w-auto">
                  Find housing <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link to="/auth" search={{ mode: "signup", role: "landlord" } as never}>
                <Button size="lg" variant="outline" className="h-12 w-full px-7 text-base sm:w-auto">
                  List a property
                </Button>
              </Link>
            </div>
            <div className="mt-10 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-sm text-muted-foreground">
              <span className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-success" /> Verified profiles</span>
              <span className="flex items-center gap-2"><Lock className="h-4 w-4 text-success" /> Private documents</span>
              <span className="flex items-center gap-2"><CalendarCheck className="h-4 w-4 text-success" /> In-app visit booking</span>
            </div>
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section id="how" className="container mx-auto max-w-7xl px-4 py-24">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="font-display text-4xl text-balance text-foreground md:text-5xl">How HomeMatch works</h2>
          <p className="mt-4 text-muted-foreground">A serious matching platform that flips the rental process in your favor.</p>
        </div>
        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {[
            { n: "01", t: "Build one verified profile", d: "Tell us who you are, your budget, move-in date, and upload documents privately." },
            { n: "02", t: "Landlords pre-approve you", d: "We surface compatible tenant cards to landlords. They click 'Interested'." },
            { n: "03", t: "You choose & book a visit", d: "Receive invitations, accept the ones you love, chat, and book a visit slot." },
          ].map((s) => (
            <Card key={s.n} className="border-border/60 p-7 shadow-card">
              <div className="font-display text-3xl text-primary">{s.n}</div>
              <h3 className="mt-3 text-lg font-semibold text-foreground">{s.t}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.d}</p>
            </Card>
          ))}
        </div>
      </section>

      {/* FOR TENANTS */}
      <section id="tenants" className="bg-surface py-24">
        <div className="container mx-auto grid max-w-7xl gap-12 px-4 md:grid-cols-2 md:items-center">
          <div>
            <Badge variant="secondary" className="mb-4">For tenants</Badge>
            <h2 className="font-display text-4xl text-foreground md:text-5xl">No more sending the same files 50 times.</h2>
            <p className="mt-4 text-muted-foreground">Build your dossier once. Get matched with landlords who already want to host you.</p>
            <ul className="mt-8 space-y-4">
              {[
                ["One verified renter profile", "Reuse it across every match. Always up to date."],
                ["Documents stay private", "Landlords see badges, not files — until you decide to share."],
                ["No ghosting", "Every invitation comes from a landlord who already showed interest."],
                ["Direct visit booking", "Pick a slot from their calendar. Done."],
              ].map(([t, d]) => (
                <li key={t} className="flex gap-3">
                  <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-success" />
                  <div><div className="font-medium text-foreground">{t}</div><div className="text-sm text-muted-foreground">{d}</div></div>
                </li>
              ))}
            </ul>
          </div>
          <Card className="overflow-hidden border-border/60 p-0 shadow-elegant">
            <div className="bg-gradient-primary p-6 text-primary-foreground">
              <div className="text-xs opacity-80">Compatibility</div>
              <div className="font-display text-5xl">92%</div>
              <div className="mt-1 text-sm opacity-90">Excellent match</div>
            </div>
            <div className="space-y-3 p-6">
              <Row icon={<FileCheck2 className="h-4 w-4" />} label="Budget fits the rent" />
              <Row icon={<Building2 className="h-4 w-4" />} label="Located in Paris 12e" />
              <Row icon={<CalendarCheck className="h-4 w-4" />} label="Move-in dates align" />
              <Row icon={<ShieldCheck className="h-4 w-4" />} label="Guarantor verified" />
            </div>
          </Card>
        </div>
      </section>

      {/* FOR LANDLORDS */}
      <section id="landlords" className="container mx-auto max-w-7xl px-4 py-24">
        <div className="grid gap-12 md:grid-cols-2 md:items-center">
          <Card className="order-2 border-border/60 p-7 shadow-card md:order-1">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-full bg-accent" />
              <div>
                <div className="font-semibold text-foreground">Sara, 22</div>
                <div className="text-xs text-muted-foreground">International student · Paris</div>
              </div>
              <Badge variant="secondary" className="ml-auto bg-success/10 text-success">88% match</Badge>
            </div>
            <p className="mt-4 text-sm text-muted-foreground">"Budget €950 · Move-in June 1 · 4 months · Guarantor verified · Non-smoker"</p>
            <div className="mt-5 flex gap-2">
              <Button variant="outline" className="flex-1">Pass</Button>
              <Button className="flex-1">Interested</Button>
            </div>
          </Card>
          <div className="order-1 md:order-2">
            <Badge variant="secondary" className="mb-4">For landlords</Badge>
            <h2 className="font-display text-4xl text-foreground md:text-5xl">Only review tenants who actually fit.</h2>
            <p className="mt-4 text-muted-foreground">No more sifting through hundreds of generic applications. See pre-scored, verified profiles.</p>
            <ul className="mt-8 space-y-4">
              {[
                ["Compatibility scoring", "Each tenant is ranked against your property's criteria."],
                ["Verification badges", "ID, income, guarantor — verified by our team."],
                ["Built-in scheduling", "Tenants book directly from your available slots."],
                ["Secure messaging", "Chat unlocks only after mutual interest."],
              ].map(([t, d]) => (
                <li key={t} className="flex gap-3">
                  <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
                  <div><div className="font-medium text-foreground">{t}</div><div className="text-sm text-muted-foreground">{d}</div></div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* TRUST */}
      <section id="trust" className="bg-surface py-24">
        <div className="container mx-auto max-w-7xl px-4">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="font-display text-4xl text-foreground md:text-5xl">Built on trust, by design.</h2>
            <p className="mt-4 text-muted-foreground">Privacy and verification are not features. They are the foundation.</p>
          </div>
          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {[
              { i: Lock, t: "Documents private by default", d: "Your ID, payslips and contracts are encrypted and never visible without your consent." },
              { i: ShieldCheck, t: "Verified renter badges", d: "Our admin team manually reviews uploaded documents and grants trust badges." },
              { i: Users, t: "Verified landlords", d: "Individual landlords and agencies are vetted before they can list a property." },
            ].map((b) => (
              <Card key={b.t} className="border-border/60 p-7 shadow-card">
                <b.i className="h-7 w-7 text-primary" />
                <h3 className="mt-4 text-lg font-semibold text-foreground">{b.t}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{b.d}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* APPOINTMENTS */}
      <section className="container mx-auto max-w-7xl px-4 py-24">
        <div className="grid gap-12 md:grid-cols-2 md:items-center">
          <div>
            <Badge variant="secondary" className="mb-4">Visit booking</Badge>
            <h2 className="font-display text-4xl text-foreground md:text-5xl">Book a visit, not a phone tag.</h2>
            <p className="mt-4 text-muted-foreground">After a match, pick from the landlord's published slots. Reminders and cancellations are handled inside the app.</p>
          </div>
          <Card className="border-border/60 p-6 shadow-card">
            <div className="mb-3 text-sm font-medium text-foreground">Available slots</div>
            {["Sat 8 Jun · 10:00", "Sat 8 Jun · 14:30", "Sun 9 Jun · 11:00"].map((s, i) => (
              <div key={s} className="flex items-center justify-between border-t border-border py-3 first:border-t-0 first:pt-0">
                <div className="flex items-center gap-3">
                  <CalendarCheck className="h-4 w-4 text-primary" />
                  <span className="text-sm">{s}</span>
                </div>
                <Button size="sm" variant={i === 0 ? "default" : "outline"}>{i === 0 ? "Book" : "Available"}</Button>
              </div>
            ))}
          </Card>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="container mx-auto max-w-7xl px-4 pb-24">
        <Card className="overflow-hidden border-0 bg-gradient-primary p-12 text-center text-primary-foreground shadow-elegant md:p-20">
          <h2 className="mx-auto max-w-2xl font-display text-4xl text-balance md:text-5xl">Your next home is one verified profile away.</h2>
          <p className="mx-auto mt-4 max-w-xl opacity-90">Join HomeMatch today — free for tenants, always.</p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link to="/auth" search={{ mode: "signup", role: "tenant" } as never}>
              <Button size="lg" variant="secondary" className="h-12 px-7 text-base">Create my renter profile</Button>
            </Link>
            <Link to="/auth" search={{ mode: "signup", role: "landlord" } as never}>
              <Button size="lg" variant="outline" className="h-12 border-primary-foreground/30 bg-transparent px-7 text-base text-primary-foreground hover:bg-primary-foreground/10">
                I'm a landlord
              </Button>
            </Link>
          </div>
        </Card>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-border/60 bg-surface py-10">
        <div className="container mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 text-xs text-muted-foreground md:flex-row">
          <div>© {new Date().getFullYear()} HomeMatch — Paris · Lyon · Nice · Marseille</div>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1"><Star className="h-3 w-3" /> 4.8 average rating</span>
            <span className="flex items-center gap-1"><MessageSquare className="h-3 w-3" /> support@homematch.app</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

function Row({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <div className="flex items-center gap-3 text-sm text-foreground">
      <span className="flex h-7 w-7 items-center justify-center rounded-full bg-success/10 text-success">{icon}</span>
      {label}
    </div>
  );
}
