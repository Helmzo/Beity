import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, type ReactNode } from "react";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/lib/auth";
import { getLandlordLikedTenants, isTenantPropertyMatch, useLocalStore } from "@/lib/localStore";
import { SwipeCard } from "@/components/SwipeCard";
import { PhotoCarousel } from "@/components/PhotoCarousel";
import { CalendarCheck, Euro, MessageSquare, Pencil, RotateCcw, UserRound, Users } from "lucide-react";

export const Route = createFileRoute("/landlord")({ component: LandlordDashboard });

function LandlordDashboard() {
  const nav = useNavigate();
  const { user, role, loading } = useAuth();
  const { state, swipeTenant, resetDemoData } = useLocalStore();

  useEffect(() => {
    if (loading) return;
    if (!user) nav({ to: "/auth" });
    else if (role && role !== "landlord") nav({ to: "/dashboard" });
  }, [loading, user, role, nav]);

  const nextTenants = useMemo(
    () => state.tenants.filter((t) => state.landlordSwipesOnTenants[t.id] == null),
    [state.tenants, state.landlordSwipesOnTenants],
  );
  const likedTenants = getLandlordLikedTenants(state);

  if (!state.myProperty) {
    return (
      <div className="min-h-screen bg-background">
        <AppHeader variant="app" />
        <main className="container mx-auto max-w-3xl px-4 py-16 text-center">
          <Card className="border-border/60 p-10 shadow-elegant">
            <h1 className="font-display text-5xl text-foreground">Add your property</h1>
            <p className="mx-auto mt-4 max-w-xl text-muted-foreground">Use the Connect-style form to add property info and multiple photos. It saves locally after refresh.</p>
            <Link to="/onboarding/landlord"><Button className="mt-8">Add property</Button></Link>
          </Card>
        </main>
      </div>
    );
  }

  const current = nextTenants[0];

  return (
    <div className="min-h-screen bg-background">
      <AppHeader variant="app" />
      <main className="container mx-auto max-w-7xl px-4 py-8">
        <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-center">
          <div>
            <Badge variant="secondary" className="mb-3">Landlord Swipe Zone</Badge>
            <h1 className="font-display text-4xl text-foreground md:text-5xl">Swipe verified tenant profiles</h1>
            <p className="mt-2 text-muted-foreground">Tinder-style tenant cards with scrollable photos and saved swipes.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Link to="/onboarding/landlord"><Button variant="outline"><Pencil className="mr-2 h-4 w-4" />Edit property</Button></Link>
            <Button variant="outline" onClick={resetDemoData}><RotateCcw className="mr-2 h-4 w-4" />Reset demo</Button>
          </div>
        </div>

        <div className="grid gap-8 lg:grid-cols-[340px_1fr_320px]">
          <Card className="h-fit border-border/60 p-5 shadow-card">
            <PhotoCarousel photos={state.myProperty.photos} alt={state.myProperty.title} className="h-56" />
            <h2 className="mt-4 text-xl font-semibold text-foreground">{state.myProperty.title}</h2>
            <p className="text-sm text-muted-foreground">{state.myProperty.district}, {state.myProperty.city}</p>
            <div className="mt-4 grid gap-2 text-sm text-muted-foreground">
              <Row icon={<Euro className="h-4 w-4" />} text={`Rent €${state.myProperty.rent}`} />
              <Row icon={<CalendarCheck className="h-4 w-4" />} text={`Available ${state.myProperty.availableDate}`} />
              <Row icon={<Users className="h-4 w-4" />} text={`${state.myProperty.bedrooms} bed · ${state.myProperty.sizeSqm} sqm`} />
            </div>
          </Card>

          <div className="flex justify-center">
            {current ? (
              <SwipeCard onSwipe={(dir) => swipeTenant(current.id, dir)}>
                <Card className="overflow-hidden border-border/60 bg-card shadow-elegant">
                  <PhotoCarousel photos={current.photos} alt={current.name} className="h-[430px]" />
                  <div className="p-5">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h2 className="text-2xl font-semibold text-foreground">{current.name}, {current.age}</h2>
                        <p className="text-sm text-muted-foreground">{current.occupation} · {current.preferredDistrict}</p>
                      </div>
                      <Badge className="bg-primary text-primary-foreground">€{current.budget}</Badge>
                    </div>
                    <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{current.bio}</p>
                    <div className="mt-4 grid grid-cols-3 gap-2 text-center text-sm">
                      <Mini label="Income" value={`€${current.monthlyIncome}`} />
                      <Mini label="People" value={current.householdSize} />
                      <Mini label="Move-in" value={current.moveInDate.slice(5)} />
                    </div>
                  </div>
                </Card>
              </SwipeCard>
            ) : (
              <Card className="flex min-h-[560px] w-full max-w-sm items-center justify-center border-border/60 p-8 text-center shadow-card">
                <div>
                  <UserRound className="mx-auto mb-4 h-10 w-10 text-primary" />
                  <h2 className="text-xl font-semibold text-foreground">No more tenants</h2>
                  <p className="mt-2 text-sm text-muted-foreground">You swiped every tenant. Reset demo to try again.</p>
                </div>
              </Card>
            )}
          </div>

          <Card className="h-fit border-border/60 p-5 shadow-card">
            <h2 className="font-display text-3xl text-foreground">Liked tenants</h2>
            <p className="mt-1 text-sm text-muted-foreground">These are the tenants you liked. Chat unlocks only after a mutual like.</p>
            <div className="mt-5 space-y-3">
              {likedTenants.length ? likedTenants.map((tenant) => {
                const matched = isTenantPropertyMatch(state, tenant.id, state.myProperty!.id);

                return (
                  <div key={tenant.id} className="overflow-hidden rounded-xl border border-border bg-card">
                    <PhotoCarousel photos={tenant.photos} alt={tenant.name} className="h-32" />
                    <div className="space-y-3 p-3">
                      <div>
                        <div className="font-medium text-foreground">{tenant.name}</div>
                        <div className="text-xs text-muted-foreground">€{tenant.budget} budget · {tenant.occupation}</div>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <Badge variant={matched ? "default" : "secondary"}>{matched ? "Matched" : "Waiting"}</Badge>
                        {matched ? (
                          <Link to="/messages">
                            <Button size="sm">
                              <MessageSquare className="mr-1.5 h-3.5 w-3.5" /> Message
                            </Button>
                          </Link>
                        ) : (
                          <Button size="sm" variant="outline" disabled>
                            <MessageSquare className="mr-1.5 h-3.5 w-3.5" /> Message
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              }) : <p className="text-sm text-muted-foreground">No liked tenants yet. Swipe right on a tenant to save them here.</p>}
            </div>
          </Card>
        </div>
      </main>
    </div>
  );
}

function Row({ icon, text }: { icon: ReactNode; text: string }) { return <div className="flex items-center gap-2">{icon}<span>{text}</span></div>; }
function Mini({ label, value }: { label: string; value: string | number }) { return <div className="rounded-lg bg-surface p-2"><div className="font-semibold text-foreground">{value}</div><div className="text-xs text-muted-foreground">{label}</div></div>; }
