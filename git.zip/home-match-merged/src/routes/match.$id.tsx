import { createFileRoute, Link } from "@tanstack/react-router";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export const Route = createFileRoute("/match/$id")({ component: MatchPage });

function MatchPage() {
  return (
    <div className="min-h-screen bg-background">
      <AppHeader variant="app" />
      <main className="container mx-auto max-w-2xl px-4 py-16">
        <Card className="border-border/60 p-8 text-center shadow-elegant">
          <h1 className="font-display text-4xl text-foreground">Match details</h1>
          <p className="mt-2 text-muted-foreground">In this portfolio demo, matches are shown directly on the tenant and landlord Swipe Zones.</p>
          <Link to="/dashboard"><Button className="mt-6">Back to Swipe Zone</Button></Link>
        </Card>
      </main>
    </div>
  );
}
