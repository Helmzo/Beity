import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { AppHeader } from "@/components/AppHeader";
import { MessagePanel } from "@/components/MessagePanel";
import { PhotoCarousel } from "@/components/PhotoCarousel";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useAuth } from "@/lib/auth";
import {
  conversationId,
  getLandlordMatches,
  getTenantMatches,
  type Property,
  type TenantProfile,
  useLocalStore,
} from "@/lib/localStore";
import { Home, MessageSquare, UserRound } from "lucide-react";

export const Route = createFileRoute("/messages")({ component: MessagesPage });

function MessagesPage() {
  const nav = useNavigate();
  const { user, role, loading } = useAuth();
  const { state, sendMessage } = useLocalStore();
  const [selectedId, setSelectedId] = useState<string | null>(null);

  useEffect(() => {
    if (loading) return;
    if (!user) nav({ to: "/auth" });
    else if (role === "admin") nav({ to: "/admin" });
  }, [loading, user, role, nav]);

  const tenantMatches = useMemo(() => getTenantMatches(state), [state]);
  const landlordMatches = useMemo(() => getLandlordMatches(state), [state]);

  const isTenant = role === "tenant";
  const matches = isTenant ? tenantMatches : landlordMatches;
  const selected = matches.find((m) => m.id === selectedId) ?? matches[0] ?? null;

  useEffect(() => {
    if (!selectedId && matches[0]) setSelectedId(matches[0].id);
    if (selectedId && !matches.some((m) => m.id === selectedId)) {
      setSelectedId(matches[0]?.id ?? null);
    }
  }, [matches, selectedId]);

  if (loading) {
    return <div className="flex min-h-screen items-center justify-center text-muted-foreground">Loading messages…</div>;
  }

  if (role === "tenant" && !state.myTenant) {
    return <MissingProfile type="tenant" />;
  }

  if (role === "landlord" && !state.myProperty) {
    return <MissingProfile type="landlord" />;
  }

  const currentRole = isTenant ? "tenant" : "landlord";
  const chatId = selected
    ? isTenant
      ? conversationId(state.myTenant!.id, (selected as Property).id)
      : conversationId((selected as TenantProfile).id, state.myProperty!.id)
    : null;

  const title = selected
    ? isTenant
      ? (selected as Property).title
      : (selected as TenantProfile).name
    : "Messages";

  const subtitle = selected
    ? isTenant
      ? `${(selected as Property).district}, ${(selected as Property).city} · mutual match`
      : `${(selected as TenantProfile).occupation} · mutual match`
    : "Only mutual matches can message.";

  return (
    <div className="min-h-screen bg-background">
      <AppHeader variant="app" />
      <main className="container mx-auto max-w-7xl px-4 py-8">
        <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <div>
            <Badge variant="secondary" className="mb-3">Messages</Badge>
            <h1 className="font-display text-4xl text-foreground md:text-5xl">Your mutual matches</h1>
            <p className="mt-2 text-muted-foreground">
              Chat is only available when both sides liked each other. Your liked items still stay in your Swipe Zone.
            </p>
          </div>
          <Link to={isTenant ? "/tenant" : "/landlord"}>
            <Button variant="outline">Back to Swipe Zone</Button>
          </Link>
        </div>

        {matches.length === 0 ? (
          <Card className="border-border/60 p-10 text-center shadow-card">
            <MessageSquare className="mx-auto mb-4 h-10 w-10 text-primary" />
            <h2 className="text-2xl font-semibold text-foreground">No mutual matches yet</h2>
            <p className="mx-auto mt-2 max-w-xl text-muted-foreground">
              Like profiles from your Swipe Zone. Messaging unlocks only when the other side likes you back.
            </p>
            <Link to={isTenant ? "/tenant" : "/landlord"}>
              <Button className="mt-6">Keep swiping</Button>
            </Link>
          </Card>
        ) : (
          <div className="grid gap-6 lg:grid-cols-[360px_1fr]">
            <Card className="h-fit border-border/60 p-4 shadow-card">
              <h2 className="font-display text-3xl text-foreground">Matches</h2>
              <p className="mt-1 text-sm text-muted-foreground">Select a match to open the conversation.</p>
              <div className="mt-5 space-y-3">
                {matches.map((match) => (
                  <MatchListItem
                    key={match.id}
                    item={match}
                    isTenant={isTenant}
                    active={selected?.id === match.id}
                    onClick={() => setSelectedId(match.id)}
                  />
                ))}
              </div>
            </Card>

            {selected && chatId && (
              <div className="space-y-4">
                <Card className="overflow-hidden border-border/60 shadow-card">
                  <PhotoCarousel
                    photos={isTenant ? (selected as Property).photos : (selected as TenantProfile).photos}
                    alt={title}
                    className="h-72"
                  />
                  <div className="p-5">
                    <div className="flex flex-col justify-between gap-3 md:flex-row md:items-start">
                      <div>
                        <h2 className="text-2xl font-semibold text-foreground">{title}</h2>
                        <p className="text-sm text-muted-foreground">{subtitle}</p>
                      </div>
                      <Badge className="bg-primary text-primary-foreground">Matched</Badge>
                    </div>
                  </div>
                </Card>

                <MessagePanel
                  title={title}
                  subtitle="Mutual match — tenant and landlord both liked each other"
                  messages={state.messages[chatId] ?? []}
                  currentRole={currentRole}
                  onSend={(body) => sendMessage(chatId, currentRole, body)}
                />
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}

function MatchListItem({
  item,
  isTenant,
  active,
  onClick,
}: {
  item: Property | TenantProfile;
  isTenant: boolean;
  active: boolean;
  onClick: () => void;
}) {
  const title = isTenant ? (item as Property).title : (item as TenantProfile).name;
  const subtitle = isTenant
    ? `${(item as Property).district} · €${(item as Property).rent}`
    : `${(item as TenantProfile).occupation} · €${(item as TenantProfile).budget} budget`;
  const photos = isTenant ? (item as Property).photos : (item as TenantProfile).photos;

  return (
    <button
      onClick={onClick}
      className={`w-full overflow-hidden rounded-xl border text-left transition ${
        active ? "border-primary bg-primary/5" : "border-border bg-card hover:border-primary/40"
      }`}
    >
      <div className="grid grid-cols-[92px_1fr] gap-3 p-2">
        <PhotoCarousel photos={photos} alt={title} className="h-20 rounded-lg" />
        <div className="min-w-0 py-1">
          <div className="flex items-center gap-2">
            {isTenant ? <Home className="h-4 w-4 text-primary" /> : <UserRound className="h-4 w-4 text-primary" />}
            <div className="truncate font-medium text-foreground">{title}</div>
          </div>
          <div className="mt-1 truncate text-xs text-muted-foreground">{subtitle}</div>
          <Badge variant="secondary" className="mt-3">Mutual match</Badge>
        </div>
      </div>
    </button>
  );
}

function MissingProfile({ type }: { type: "tenant" | "landlord" }) {
  return (
    <div className="min-h-screen bg-background">
      <AppHeader variant="app" />
      <main className="container mx-auto max-w-3xl px-4 py-16 text-center">
        <Card className="border-border/60 p-10 shadow-card">
          <h1 className="font-display text-5xl text-foreground">
            {type === "tenant" ? "Create your renter profile first" : "Add your property first"}
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
            You need a profile before messages and matches can appear.
          </p>
          <Link to={type === "tenant" ? "/onboarding/tenant" : "/onboarding/landlord"}>
            <Button className="mt-8">Get started</Button>
          </Link>
        </Card>
      </main>
    </div>
  );
}
