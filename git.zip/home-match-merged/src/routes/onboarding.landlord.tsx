import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { splitPhotoInput, useLocalStore, type Property } from "@/lib/localStore";
import { toast } from "sonner";

export const Route = createFileRoute("/onboarding/landlord")({ component: LandlordOnboarding });

function LandlordOnboarding() {
  const nav = useNavigate();
  const { state, saveProperty } = useLocalStore();
  const p = state.myProperty;
  const [form, setForm] = useState({
    title: p?.title ?? "",
    district: p?.district ?? "",
    city: p?.city ?? "Toulon",
    rent: String(p?.rent ?? 750),
    bedrooms: String(p?.bedrooms ?? 1),
    bathrooms: String(p?.bathrooms ?? 1),
    sizeSqm: String(p?.sizeSqm ?? 35),
    furnished: p?.furnished ?? true,
    petsAllowed: p?.petsAllowed ?? false,
    description: p?.description ?? "",
    landlordName: p?.landlordName ?? "",
    availableDate: p?.availableDate ?? "2026-07-01",
    photos: (p?.photos ?? []).join("\n"),
  });

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const photos = splitPhotoInput(form.photos);
    const property: Property = {
      id: p?.id ?? "my-property",
      title: form.title || "Demo property",
      district: form.district,
      city: form.city,
      rent: Number(form.rent) || 0,
      bedrooms: Number(form.bedrooms) || 1,
      bathrooms: Number(form.bathrooms) || 1,
      sizeSqm: Number(form.sizeSqm) || 0,
      furnished: form.furnished,
      petsAllowed: form.petsAllowed,
      description: form.description,
      photos,
      landlordName: form.landlordName || "Demo landlord",
      availableDate: form.availableDate,
    };
    saveProperty(property);
    toast.success("Property saved locally");
    nav({ to: "/landlord" });
  }

  return (
    <div className="min-h-screen bg-background">
      <AppHeader variant="app" />
      <main className="container mx-auto max-w-4xl px-4 py-10">
        <Card className="border-border/60 p-7 shadow-elegant">
          <h1 className="font-display text-4xl text-foreground">Add your property</h1>
          <p className="mt-2 text-sm text-muted-foreground">Add the information and multiple photo URLs. It saves in localStorage after refresh.</p>
          <form onSubmit={submit} className="mt-8 grid gap-5 md:grid-cols-2">
            <Field label="Property title"><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></Field>
            <Field label="Landlord / agency name"><Input value={form.landlordName} onChange={(e) => setForm({ ...form, landlordName: e.target.value })} /></Field>
            <Field label="City"><Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></Field>
            <Field label="District"><Input value={form.district} onChange={(e) => setForm({ ...form, district: e.target.value })} /></Field>
            <Field label="Rent"><Input type="number" value={form.rent} onChange={(e) => setForm({ ...form, rent: e.target.value })} /></Field>
            <Field label="Size sqm"><Input type="number" value={form.sizeSqm} onChange={(e) => setForm({ ...form, sizeSqm: e.target.value })} /></Field>
            <Field label="Bedrooms"><Input type="number" value={form.bedrooms} onChange={(e) => setForm({ ...form, bedrooms: e.target.value })} /></Field>
            <Field label="Bathrooms"><Input type="number" value={form.bathrooms} onChange={(e) => setForm({ ...form, bathrooms: e.target.value })} /></Field>
            <Field label="Available date"><Input type="date" value={form.availableDate} onChange={(e) => setForm({ ...form, availableDate: e.target.value })} /></Field>
            <div className="grid gap-3 rounded-xl border border-border p-4 md:col-span-2 md:grid-cols-2">
              <Toggle label="Furnished" checked={form.furnished} onChange={(furnished) => setForm({ ...form, furnished })} />
              <Toggle label="Pets allowed" checked={form.petsAllowed} onChange={(petsAllowed) => setForm({ ...form, petsAllowed })} />
            </div>
            <Field label="Description" className="md:col-span-2"><Textarea rows={4} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></Field>
            <Field label="Photo URLs, one per line. Add as many as you want." className="md:col-span-2"><Textarea rows={5} value={form.photos} onChange={(e) => setForm({ ...form, photos: e.target.value })} placeholder="https://...jpg\nhttps://...jpg" /></Field>
            <div className="md:col-span-2 flex gap-3">
              <Button type="submit">Save property</Button>
              <Button type="button" variant="outline" onClick={() => nav({ to: "/landlord" })}>Cancel</Button>
            </div>
          </form>
        </Card>
      </main>
    </div>
  );
}

function Field({ label, children, className = "" }: { label: string; children: ReactNode; className?: string }) {
  return <div className={`space-y-1.5 ${className}`}><Label>{label}</Label>{children}</div>;
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return <div className="flex items-center justify-between gap-4"><Label>{label}</Label><Switch checked={checked} onCheckedChange={onChange} /></div>;
}
