import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { useLocalStore, splitPhotoInput, type TenantProfile } from "@/lib/localStore";
import { toast } from "sonner";

export const Route = createFileRoute("/onboarding/tenant")({ component: TenantOnboarding });

function TenantOnboarding() {
  const nav = useNavigate();
  const { state, saveTenant } = useLocalStore();
  const t = state.myTenant;
  const [form, setForm] = useState({
    name: t?.name ?? "",
    age: String(t?.age ?? 22),
    occupation: t?.occupation ?? "",
    monthlyIncome: String(t?.monthlyIncome ?? 2500),
    budget: String(t?.budget ?? 900),
    householdSize: String(t?.householdSize ?? 1),
    pets: t?.pets ?? false,
    smoker: t?.smoker ?? false,
    bio: t?.bio ?? "",
    moveInDate: t?.moveInDate ?? "2026-07-01",
    preferredDistrict: t?.preferredDistrict ?? "",
    desiredCity: t?.desiredCity ?? "Toulon",
    hasGuarantor: t?.hasGuarantor ?? true,
    photos: (t?.photos ?? []).join("\n"),
  });

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const photos = splitPhotoInput(form.photos);
    const profile: TenantProfile = {
      id: t?.id ?? "my-tenant",
      name: form.name || "Demo Tenant",
      age: Number(form.age) || 18,
      occupation: form.occupation || "Student",
      monthlyIncome: Number(form.monthlyIncome) || 0,
      budget: Number(form.budget) || 0,
      householdSize: Number(form.householdSize) || 1,
      pets: form.pets,
      smoker: form.smoker,
      bio: form.bio,
      photo: photos[0] ?? "",
      photos,
      moveInDate: form.moveInDate,
      preferredDistrict: form.preferredDistrict,
      desiredCity: form.desiredCity,
      hasGuarantor: form.hasGuarantor,
    };
    saveTenant(profile);
    toast.success("Tenant profile saved locally");
    nav({ to: "/tenant" });
  }

  return (
    <div className="min-h-screen bg-background">
      <AppHeader variant="app" />
      <main className="container mx-auto max-w-4xl px-4 py-10">
        <Card className="border-border/60 p-7 shadow-elegant">
          <h1 className="font-display text-4xl text-foreground">Create your tenant profile</h1>
          <p className="mt-2 text-sm text-muted-foreground">Everything you add here is saved in your browser and stays after refresh.</p>

          <form onSubmit={submit} className="mt-8 grid gap-5 md:grid-cols-2">
            <Field label="Full name"><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
            <Field label="Age"><Input type="number" value={form.age} onChange={(e) => setForm({ ...form, age: e.target.value })} /></Field>
            <Field label="Occupation"><Input value={form.occupation} onChange={(e) => setForm({ ...form, occupation: e.target.value })} /></Field>
            <Field label="Monthly income"><Input type="number" value={form.monthlyIncome} onChange={(e) => setForm({ ...form, monthlyIncome: e.target.value })} /></Field>
            <Field label="Max budget"><Input type="number" value={form.budget} onChange={(e) => setForm({ ...form, budget: e.target.value })} /></Field>
            <Field label="Household size"><Input type="number" value={form.householdSize} onChange={(e) => setForm({ ...form, householdSize: e.target.value })} /></Field>
            <Field label="Desired city"><Input value={form.desiredCity} onChange={(e) => setForm({ ...form, desiredCity: e.target.value })} /></Field>
            <Field label="Preferred district"><Input value={form.preferredDistrict} onChange={(e) => setForm({ ...form, preferredDistrict: e.target.value })} /></Field>
            <Field label="Move-in date"><Input type="date" value={form.moveInDate} onChange={(e) => setForm({ ...form, moveInDate: e.target.value })} /></Field>
            <div className="grid gap-3 rounded-xl border border-border p-4 md:col-span-2 md:grid-cols-3">
              <Toggle label="Pets" checked={form.pets} onChange={(pets) => setForm({ ...form, pets })} />
              <Toggle label="Smoker" checked={form.smoker} onChange={(smoker) => setForm({ ...form, smoker })} />
              <Toggle label="Guarantor" checked={form.hasGuarantor} onChange={(hasGuarantor) => setForm({ ...form, hasGuarantor })} />
            </div>
            <Field label="Bio" className="md:col-span-2"><Textarea rows={4} value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} placeholder="Short description about you..." /></Field>
            <Field label="Photo URLs, one per line. You can add your own later." className="md:col-span-2"><Textarea rows={5} value={form.photos} onChange={(e) => setForm({ ...form, photos: e.target.value })} placeholder="https://...jpg\nhttps://...jpg" /></Field>
            <div className="md:col-span-2 flex gap-3">
              <Button type="submit">Save profile</Button>
              <Button type="button" variant="outline" onClick={() => nav({ to: "/tenant" })}>Cancel</Button>
            </div>
          </form>
        </Card>
      </main>
    </div>
  );
}

function Field({ label, children, className = "" }: { label: string; children: ReactNode; className?: string }) {
  return <div className={`space-y-1.5 ${className}`}><Label>{label}</Label>{children}</div>;
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return <div className="flex items-center justify-between gap-4"><Label>{label}</Label><Switch checked={checked} onCheckedChange={onChange} /></div>;
}
