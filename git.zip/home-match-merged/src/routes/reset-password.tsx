import { createFileRoute, Link } from "@tanstack/react-router";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export const Route = createFileRoute("/reset-password")({ component: ResetPassword });

function ResetPassword() {
  return (
    <div className="min-h-screen bg-hero">
      <AppHeader variant="public" />
      <main className="container mx-auto max-w-md px-4 py-16">
        <Card className="border-border/60 p-8 shadow-elegant">
          <h1 className="font-display text-3xl text-foreground">Password reset disabled</h1>
          <p className="mt-2 text-sm text-muted-foreground">This portfolio version uses a local demo password, so there is no real password reset.</p>
          <Link to="/auth"><Button className="mt-6 w-full">Back to demo login</Button></Link>
        </Card>
      </main>
    </div>
  );
}
