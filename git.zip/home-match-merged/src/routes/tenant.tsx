import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, type ReactNode } from "react";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/lib/auth";
import { getTenantLikedProperties, isTenantPropertyMatch, useLocalStore } from "@/lib/localStore";
import { SwipeCard } from "@/components/SwipeCard";
import { PhotoCarousel } from "@/components/PhotoCarousel";
import { CalendarCheck, Euro, Home, MapPin, MessageSquare, Pencil, RotateCcw, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/tenant")({ component: TenantDashboard });

function TenantDashboard() {
  const nav = useNavigate();
  const { user, role, loading } = useAuth();
  const { state, swipeProperty, resetDemoData } = useLocalStore();

  useEffect(() => {
    if (loading) return;
    if (!user) nav({ to: "/auth" });
    else if (role && role !== "tenant") nav({ to: "/dashboard" });
  }, [loading, user, role, nav]);

  const nextProperties = useMemo(
    () => state.properties.filter((p) => state.tenantSwipesOnProps[p.id] == null),
    [state.properties, state.tenantSwipesOnProps],
  );
  const likedProperties = getTenantLikedProperties(state);

  if (!state.myTenant) {
    return (
      <div className="min-h-screen bg-background">
        <AppHeader variant="app" />
        <main className="container mx-auto max-w-3xl px-4 py-16 text-center">
          <Card className="border-border/60 p-10 shadow-elegant">
            <h1 className="font-display text-5xl text-foreground">Build your renter profile</h1>
            <p className="mx-auto mt-4 max-w-xl text-muted-foreground">Use the Connect-style form, add your information, and save it locally so it stays after reload.</p>
            <Link to="/onboarding/tenant"><Button className="mt-8">Create profile</Button></Link>
          </Card>
        </main>
      </div>
    );
  }

  const current = nextProperties[0];

  return (
    <div className="min-h-screen bg-background">
      <AppHeader variant="app" />
      <main className="container mx-auto max-w-7xl px-4 py-8">
        <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-center">
          <div>
            <Badge variant="secondary" className="mb-3">Tenant Swipe Zone</Badge>
            <h1 className="font-display text-4xl text-foreground md:text-5xl">Homes that already fit you</h1>
            <p className="mt-2 text-muted-foreground">Swipe through properties with multiple photos. Your profile and swipes are saved locally.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Link to="/onboarding/tenant"><Button variant="outline"><Pencil className="mr-2 h-4 w-4" />Edit profile</Button></Link>
            <Button variant="outline" onClick={resetDemoData}><RotateCcw className="mr-2 h-4 w-4" />Reset demo</Button>
          </div>
        </div>

        <div className="grid gap-8 lg:grid-cols-[340px_1fr_320px]">
          <Card className="h-fit border-border/60 p-5 shadow-card">
            <PhotoCarousel photos={state.myTenant.photos} alt={state.myTenant.name} className="h-56" />
            <h2 className="mt-4 text-xl font-semibold text-foreground">{state.myTenant.name}, {state.myTenant.age}</h2>
            <p className="text-sm text-muted-foreground">{state.myTenant.occupation}</p>
            <div className="mt-4 grid gap-2 text-sm text-muted-foreground">
              <Row icon={<Euro className="h-4 w-4" />} text={`Budget €${state.myTenant.budget}`} />
              <Row icon={<MapPin className="h-4 w-4" />} text={`${state.myTenant.desiredCity} · ${state.myTenant.preferredDistrict || "Any area"}`} />
              <Row icon={<CalendarCheck className="h-4 w-4" />} text={`Move-in ${state.myTenant.moveInDate}`} />
              <Row icon={<ShieldCheck className="h-4 w-4" />} text={state.myTenant.hasGuarantor ? "Guarantor available" : "No guarantor"} />
            </div>
          </Card>

          <div className="flex justify-center">
            {current ? (
              <SwipeCard onSwipe={(dir) => swipeProperty(current.id, dir)}>
                <Card className="overflow-hidden border-border/60 bg-card shadow-elegant">
                  <PhotoCarousel photos={current.photos} alt={current.title} className="h-[430px]" />
                  <div className="p-5">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h2 className="text-2xl font-semibold text-foreground">{current.title}</h2>
                        <p className="text-sm text-muted-foreground">{current.district}, {current.city}</p>
                      </div>
                      <Badge className="bg-primary text-primary-foreground">€{current.rent}</Badge>
                    </div>
                    <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{current.description}</p>
                    <div className="mt-4 grid grid-cols-3 gap-2 text-center text-sm">
                      <Mini label="Beds" value={current.bedrooms} />
                      <Mini label="Baths" value={current.bathrooms} />
                      <Mini label="sqm" value={current.sizeSqm} />
                    </div>
                  </div>
                </Card>
              </SwipeCard>
            ) : (
              <Card className="flex min-h-[560px] w-full max-w-sm items-center justify-center border-border/60 p-8 text-center shadow-card">
                <div>
                  <Home className="mx-auto mb-4 h-10 w-10 text-primary" />
                  <h2 className="text-xl font-semibold text-foreground">No more cards</h2>
                  <p className="mt-2 text-sm text-muted-foreground">You swiped every available property. Reset demo to try again.</p>
                </div>
              </Card>
            )}
          </div>

          <Card className="h-fit border-border/60 p-5 shadow-card">
            <h2 className="font-display text-3xl text-foreground">Liked homes</h2>
            <p className="mt-1 text-sm text-muted-foreground">These are the properties you liked. Chat unlocks only after a mutual like.</p>
            <div className="mt-5 space-y-3">
              {likedProperties.length ? likedProperties.map((property) => {
                const matched = isTenantPropertyMatch(state, state.myTenant!.id, property.id);

                return (
                  <div key={property.id} className="overflow-hidden rounded-xl border border-border bg-card">
                    <PhotoCarousel photos={property.photos} alt={property.title} className="h-32" />
                    <div className="space-y-3 p-3">
                      <div>
                        <div className="font-medium text-foreground">{property.title}</div>
                        <div className="text-xs text-muted-foreground">€{property.rent} · {property.district}</div>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <Badge variant={matched ? "default" : "secondary"}>{matched ? "Matched" : "Waiting"}</Badge>
                        {matched ? (
                          <Link to="/messages">
                            <Button size="sm">
                              <MessageSquare className="mr-1.5 h-3.5 w-3.5" /> Message
                            </Button>
                          </Link>
                        ) : (
                          <Button size="sm" variant="outline" disabled>
                            <MessageSquare className="mr-1.5 h-3.5 w-3.5" /> Message
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              }) : <p className="text-sm text-muted-foreground">No liked homes yet. Swipe right on a property to save it here.</p>}
            </div>
          </Card>
        </div>
      </main>
    </div>
  );
}

function Row({ icon, text }: { icon: ReactNode; text: string }) { return <div className="flex items-center gap-2">{icon}<span>{text}</span></div>; }
function Mini({ label, value }: { label: string; value: string | number }) { return <div className="rounded-lg bg-surface p-2"><div className="font-semibold text-foreground">{value}</div><div className="text-xs text-muted-foreground">{label}</div></div>; }
