
-- ENUMS
create type public.app_role as enum ('tenant','landlord','admin');
create type public.property_term as enum ('short','medium','long');
create type public.housing_type as enum ('studio','apartment','house','room','colocation');
create type public.tenant_situation as enum ('student','employee','intern','expat','young_professional','other');
create type public.interest_status as enum ('pending','accepted','declined');
create type public.match_status as enum ('active','closed');
create type public.booking_status as enum ('booked','cancelled','completed');
create type public.doc_type as enum ('id','income','student_certificate','employment_contract','guarantor','other');
create type public.verification_status as enum ('pending','approved','rejected');

-- USER ROLES (separate table per security best practice)
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id=_user_id and role=_role)
$$;

create or replace function public.is_admin(_user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.has_role(_user_id,'admin')
$$;

-- BASE PROFILES (one row per user, common info)
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  avatar_url text,
  city text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- TENANT PROFILES
create table public.tenant_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  age int,
  intro text,
  desired_city text,
  desired_area text,
  budget_min int,
  budget_max int,
  move_in_date date,
  stay_months int,
  housing_type housing_type,
  furnished boolean,
  situation tenant_situation,
  income_min int,
  income_max int,
  has_guarantor boolean default false,
  has_pets boolean default false,
  smoker boolean default false,
  completion int not null default 0,
  is_verified boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- LANDLORD PROFILES
create table public.landlord_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  is_agency boolean not null default false,
  company_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- PROPERTIES
create table public.properties (
  id uuid primary key default gen_random_uuid(),
  landlord_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  description text,
  city text not null,
  area text,
  address text, -- hidden until match
  rent int not null,
  available_date date not null,
  term property_term not null default 'long',
  furnished boolean not null default true,
  rooms int not null default 1,
  surface int,
  housing_type housing_type not null default 'apartment',
  rules text,
  required_docs text[] default array['id','income']::text[],
  photos text[] default array[]::text[],
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- TENANT DOCUMENTS (private storage refs)
create table public.tenant_documents (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references auth.users(id) on delete cascade,
  doc_type doc_type not null,
  storage_path text not null,
  filename text not null,
  verification verification_status not null default 'pending',
  created_at timestamptz not null default now()
);

-- VERIFICATION BADGES (granted by admin)
create table public.verification_badges (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references auth.users(id) on delete cascade,
  badge text not null, -- 'id','income','guarantor','student','employment'
  granted_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  unique (tenant_id, badge)
);

-- MATCH INTERESTS (landlord -> tenant for a property)
create table public.match_interests (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references public.properties(id) on delete cascade,
  landlord_id uuid not null references auth.users(id) on delete cascade,
  tenant_id uuid not null references auth.users(id) on delete cascade,
  score int not null default 0,
  status interest_status not null default 'pending',
  created_at timestamptz not null default now(),
  responded_at timestamptz,
  unique (property_id, tenant_id)
);

-- MATCHES (accepted)
create table public.matches (
  id uuid primary key default gen_random_uuid(),
  interest_id uuid not null unique references public.match_interests(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  landlord_id uuid not null references auth.users(id) on delete cascade,
  tenant_id uuid not null references auth.users(id) on delete cascade,
  status match_status not null default 'active',
  created_at timestamptz not null default now()
);

-- VISIT SLOTS
create table public.visit_slots (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references public.properties(id) on delete cascade,
  landlord_id uuid not null references auth.users(id) on delete cascade,
  starts_at timestamptz not null,
  duration_min int not null default 30,
  is_booked boolean not null default false,
  created_at timestamptz not null default now()
);

-- BOOKINGS
create table public.bookings (
  id uuid primary key default gen_random_uuid(),
  slot_id uuid not null unique references public.visit_slots(id) on delete cascade,
  match_id uuid not null references public.matches(id) on delete cascade,
  tenant_id uuid not null references auth.users(id) on delete cascade,
  landlord_id uuid not null references auth.users(id) on delete cascade,
  status booking_status not null default 'booked',
  created_at timestamptz not null default now()
);

-- DOCUMENT UNLOCKS (tenant grants landlord access to specific doc within a match)
create table public.document_unlocks (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  document_id uuid not null references public.tenant_documents(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (match_id, document_id)
);

-- MESSAGES
create table public.messages (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now()
);

-- NOTIFICATIONS
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  body text,
  link text,
  read boolean not null default false,
  created_at timestamptz not null default now()
);

-- REPORTS
create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users(id) on delete cascade,
  target_user_id uuid references auth.users(id) on delete cascade,
  target_property_id uuid references public.properties(id) on delete cascade,
  reason text not null,
  resolved boolean not null default false,
  created_at timestamptz not null default now()
);

-- TIMESTAMPS TRIGGER
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;
create trigger trg_profiles_updated before update on public.profiles for each row execute function public.touch_updated_at();
create trigger trg_tenant_updated before update on public.tenant_profiles for each row execute function public.touch_updated_at();
create trigger trg_landlord_updated before update on public.landlord_profiles for each row execute function public.touch_updated_at();
create trigger trg_property_updated before update on public.properties for each row execute function public.touch_updated_at();

-- AUTO CREATE PROFILE
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name) values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- ENABLE RLS
alter table public.user_roles enable row level security;
alter table public.profiles enable row level security;
alter table public.tenant_profiles enable row level security;
alter table public.landlord_profiles enable row level security;
alter table public.properties enable row level security;
alter table public.tenant_documents enable row level security;
alter table public.verification_badges enable row level security;
alter table public.match_interests enable row level security;
alter table public.matches enable row level security;
alter table public.visit_slots enable row level security;
alter table public.bookings enable row level security;
alter table public.document_unlocks enable row level security;
alter table public.messages enable row level security;
alter table public.notifications enable row level security;
alter table public.reports enable row level security;

-- POLICIES
-- user_roles: user reads own; admin all
create policy "own roles read" on public.user_roles for select using (auth.uid()=user_id or public.is_admin(auth.uid()));
create policy "self insert role on signup" on public.user_roles for insert with check (auth.uid()=user_id);
create policy "admin manage roles" on public.user_roles for all using (public.is_admin(auth.uid())) with check (public.is_admin(auth.uid()));

-- profiles: everyone authenticated can read basic; users update own
create policy "auth read profiles" on public.profiles for select using (auth.role()='authenticated');
create policy "update own profile" on public.profiles for update using (auth.uid()=id);
create policy "insert own profile" on public.profiles for insert with check (auth.uid()=id);

-- tenant_profiles: owner full; landlords/admins read (no docs here)
create policy "tenant read own" on public.tenant_profiles for select using (auth.uid()=id or public.has_role(auth.uid(),'landlord') or public.is_admin(auth.uid()));
create policy "tenant write own" on public.tenant_profiles for all using (auth.uid()=id) with check (auth.uid()=id);

-- landlord_profiles
create policy "landlord read" on public.landlord_profiles for select using (auth.role()='authenticated');
create policy "landlord write own" on public.landlord_profiles for all using (auth.uid()=id) with check (auth.uid()=id);

-- properties: active visible to all auth; owner full; admin full
create policy "properties read" on public.properties for select using (auth.role()='authenticated');
create policy "landlord manage own props" on public.properties for all using (auth.uid()=landlord_id or public.is_admin(auth.uid())) with check (auth.uid()=landlord_id or public.is_admin(auth.uid()));

-- tenant_documents: owner + admin; landlords ONLY via unlock
create policy "docs owner" on public.tenant_documents for all using (auth.uid()=tenant_id or public.is_admin(auth.uid())) with check (auth.uid()=tenant_id);
create policy "docs unlocked to landlord" on public.tenant_documents for select using (
  exists (select 1 from public.document_unlocks du join public.matches m on m.id=du.match_id
    where du.document_id = tenant_documents.id and m.landlord_id = auth.uid())
);

-- verification_badges: anyone auth can read (it's a badge); only admin writes
create policy "badges read" on public.verification_badges for select using (auth.role()='authenticated');
create policy "badges admin" on public.verification_badges for all using (public.is_admin(auth.uid())) with check (public.is_admin(auth.uid()));

-- match_interests: landlord (owner) and tenant (recipient); admin
create policy "interests visible" on public.match_interests for select using (
  auth.uid()=landlord_id or auth.uid()=tenant_id or public.is_admin(auth.uid())
);
create policy "landlord create interest" on public.match_interests for insert with check (auth.uid()=landlord_id);
create policy "tenant respond interest" on public.match_interests for update using (auth.uid()=tenant_id or auth.uid()=landlord_id);

-- matches: parties + admin
create policy "match parties read" on public.matches for select using (
  auth.uid()=landlord_id or auth.uid()=tenant_id or public.is_admin(auth.uid())
);
create policy "match parties insert" on public.matches for insert with check (
  auth.uid()=landlord_id or auth.uid()=tenant_id
);
create policy "match parties update" on public.matches for update using (
  auth.uid()=landlord_id or auth.uid()=tenant_id
);

-- visit_slots: anyone auth can read; landlord manages
create policy "slots read" on public.visit_slots for select using (auth.role()='authenticated');
create policy "slots landlord manage" on public.visit_slots for all using (auth.uid()=landlord_id) with check (auth.uid()=landlord_id);

-- bookings: parties
create policy "bookings read" on public.bookings for select using (
  auth.uid()=tenant_id or auth.uid()=landlord_id or public.is_admin(auth.uid())
);
create policy "bookings tenant insert" on public.bookings for insert with check (auth.uid()=tenant_id);
create policy "bookings parties update" on public.bookings for update using (auth.uid()=tenant_id or auth.uid()=landlord_id);

-- document_unlocks: tenant (owner of doc) writes; landlord in match reads
create policy "unlocks read parties" on public.document_unlocks for select using (
  exists (select 1 from public.matches m where m.id=document_unlocks.match_id and (m.tenant_id=auth.uid() or m.landlord_id=auth.uid()))
);
create policy "unlocks tenant write" on public.document_unlocks for insert with check (
  exists (select 1 from public.matches m where m.id=document_unlocks.match_id and m.tenant_id=auth.uid())
);
create policy "unlocks tenant delete" on public.document_unlocks for delete using (
  exists (select 1 from public.matches m where m.id=document_unlocks.match_id and m.tenant_id=auth.uid())
);

-- messages: match parties
create policy "messages read" on public.messages for select using (
  exists (select 1 from public.matches m where m.id=messages.match_id and (m.tenant_id=auth.uid() or m.landlord_id=auth.uid()))
);
create policy "messages send" on public.messages for insert with check (
  sender_id = auth.uid() and exists (select 1 from public.matches m where m.id=match_id and (m.tenant_id=auth.uid() or m.landlord_id=auth.uid()))
);

-- notifications
create policy "notif own" on public.notifications for all using (auth.uid()=user_id) with check (auth.uid()=user_id);

-- reports: reporter + admin
create policy "report own read" on public.reports for select using (auth.uid()=reporter_id or public.is_admin(auth.uid()));
create policy "report create" on public.reports for insert with check (auth.uid()=reporter_id);
create policy "report admin update" on public.reports for update using (public.is_admin(auth.uid()));

-- STORAGE BUCKETS
insert into storage.buckets (id,name,public) values ('property-photos','property-photos',true) on conflict do nothing;
insert into storage.buckets (id,name,public) values ('tenant-documents','tenant-documents',false) on conflict do nothing;
insert into storage.buckets (id,name,public) values ('avatars','avatars',true) on conflict do nothing;

-- Storage policies
create policy "property photos public read" on storage.objects for select using (bucket_id='property-photos');
create policy "property photos landlord write" on storage.objects for insert with check (bucket_id='property-photos' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "property photos landlord update" on storage.objects for update using (bucket_id='property-photos' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "property photos landlord delete" on storage.objects for delete using (bucket_id='property-photos' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "avatars public read" on storage.objects for select using (bucket_id='avatars');
create policy "avatars owner write" on storage.objects for insert with check (bucket_id='avatars' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "avatars owner update" on storage.objects for update using (bucket_id='avatars' and auth.uid()::text = (storage.foldername(name))[1]);

-- tenant documents: only owner can read/write
create policy "docs tenant read" on storage.objects for select using (bucket_id='tenant-documents' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "docs tenant write" on storage.objects for insert with check (bucket_id='tenant-documents' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "docs tenant update" on storage.objects for update using (bucket_id='tenant-documents' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "docs tenant delete" on storage.objects for delete using (bucket_id='tenant-documents' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "docs admin read" on storage.objects for select using (bucket_id='tenant-documents' and public.is_admin(auth.uid()));

-- Realtime
alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.notifications;
alter publication supabase_realtime add table public.match_interests;
