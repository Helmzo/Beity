
alter function public.touch_updated_at() set search_path = public;
alter function public.handle_new_user() set search_path = public;
-- restrict execute to authenticated only
revoke execute on function public.has_role(uuid, app_role) from public, anon;
revoke execute on function public.is_admin(uuid) from public, anon;
grant execute on function public.has_role(uuid, app_role) to authenticated;
grant execute on function public.is_admin(uuid) to authenticated;
